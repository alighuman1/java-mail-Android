package com.soccer.voicerecorder;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.icu.text.SimpleDateFormat;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;




import java.io.IOException;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = "AudioRecordTest";
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    private static String fileName = null;
    private MediaRecorder recorder = null;
    private MediaPlayer player = null;
    private int seconds = 0;
    private boolean running;
    TextView textView5;
    int min = 100;
    int max = 2147483645;
    String email,password;
int x=-1;
    int random;
    ConstraintLayout constraintLayout;TextView Savebuton;
    EditText editText;
    // Requesting permission to RECORD_AUDIO
    private boolean permissionToRecordAccepted = false;
    private String [] permissions = {Manifest.permission.RECORD_AUDIO};

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case REQUEST_RECORD_AUDIO_PERMISSION:
                permissionToRecordAccepted  = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                break;
        }
        if (!permissionToRecordAccepted ) finish();

    }
    private void onRecord(boolean start) {
        if (start) {
            startRecording();
        } else {
            stopRecording();
        }
    }

    private void startRecording() {
        recorder = new MediaRecorder();
        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        recorder.setOutputFile(fileName);
        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);

        try {
            recorder.prepare();
        } catch (IOException e) {
            Log.e(LOG_TAG, "prepare() failed");
        }

        recorder.start();
    }


    private void stopRecording() {
        recorder.stop();
        recorder.release();
        recorder = null;
    }
    boolean mStartRecording = true;
    @SuppressLint("SetTextI18n")
    public void record() {
        onRecord(mStartRecording);
                if (mStartRecording) {
                    mStartRecording = false;
                } else {
                    mStartRecording = true;
                }
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(R.layout.activity_main);

        random = new Random().nextInt((max - min) + 1) + min;
        fileName = getExternalCacheDir().getAbsolutePath();
        fileName += "/"+random+"audio.3gp";


        SharedPreferences preferences14 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        email = preferences14.getString("email","noreply486486@gmail.com");


        ActivityCompat.requestPermissions(this, permissions, REQUEST_RECORD_AUDIO_PERMISSION);
textView5=findViewById(R.id.textView5);
constraintLayout=findViewById(R.id.contsrainlayout);
       // runTimer();
       // record();
        //onClickStart();
    }
    public void onClickStart()
    {
        running = true;
    }
    @Override
    public void onSaveInstanceState(
            Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState
                .putInt("seconds", seconds);
        savedInstanceState
                .putBoolean("running", running);

    }
    private void runTimer()
    {
        final TextView timeView
                = (TextView)findViewById(
                R.id.textview);
        final Handler handler
                = new Handler();
        handler.post(new Runnable() {
            @Override
            public void run()
            {
                int hours = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;
                String time
                        = String
                        .format(Locale.getDefault(),
                                "%d:%02d:%02d", hours,
                                minutes, secs);
                timeView.setText(time);
                if (running) {
                    seconds++;
                }
                handler.postDelayed(this, 1000);
            }}); }
    @Override
    public void onStop() {
        super.onStop();
        if (recorder != null) {
            recorder.release();
            recorder = null;
        }

        if (player != null) {
            player.release();
            player = null;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("IntentReset")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);



    }




    public void emailchange(View view) {
        textView5.setVisibility(View.VISIBLE);

    }

    public void emailchangebutton(View view) {
        constraintLayout.setVisibility(View.VISIBLE);
        textView5.setVisibility(View.INVISIBLE);
    }

    public void screen(View view) {
        textView5.setVisibility(View.INVISIBLE);
        constraintLayout.setVisibility(View.INVISIBLE);
    }

    public void save(View view) {
        editText=findViewById(R.id.editTextTextPersonName);
        String edittexts=editText.getText().toString();
        if(edittexts.isEmpty())
        {
            Toast.makeText(this,"Please enter email!",Toast.LENGTH_SHORT).show();
        }
        else {
            SharedPreferences comingcode = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            SharedPreferences.Editor editor = comingcode.edit();
            editor.putString("email", edittexts);
            editor.apply();
            SharedPreferences preferences14 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            email = preferences14.getString("email","gpark1234@gmail.com");
            Toast.makeText(this, "Email Saved!", Toast.LENGTH_SHORT).show();
            constraintLayout.setVisibility(View.INVISIBLE);
            textView5.setVisibility(View.INVISIBLE);
        }

    }
  //  static final ExecutorService emailExecutor = Executors.newSingleThreadExecutor();
    @RequiresApi(api = Build.VERSION_CODES.N)

    private void sendEmail( String Sender, String Password,String Receiver,String Title, String Message,String file,int random)
    {

        new Thread(new Runnable() {


            @Override
            public void run() {
                try {
                    GMailSender sender = new GMailSender(Sender,Password);
                    sender.sendMail(Title, "<b>"+Message+"</b>", Sender, Receiver,file,random);
                    makeAlert();

                } catch (Exception e) {
                    Log.e("SendMail", e.getMessage(), e);
                }
            }

        }).start();
    }
    private void makeAlert(){
        this.runOnUiThread(new Runnable() {
            public void run() {
                Toast.makeText(MainActivity.this, "Mail Sent", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
      //  Toast.makeText(this,"helo",Toast.LENGTH_SHORT).show();
     
        x++;

        if(hasFocus)
        {
           startRecording();
          // runTimer();
        //   Toast.makeText(this,String.valueOf(x),Toast.LENGTH_SHORT).show();
        }
        if(!hasFocus)
        {
           // Toast.makeText(this,String.valueOf(x)+"s",Toast.LENGTH_SHORT).show();
            if(x==0)
            {

            }
            else {
                stopRecording();
                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                sendEmail("noreply486486@gmail.com", "Ghuman486", email, "Recording" + date, "Audio", fileName, random);

            }
        }


    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_POWER) {
            stopRecording();
            String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            sendEmail("noreply486486@gmail.com", "Ghuman486", email, "Recording" + date, "Audio", fileName, random);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


}